REWIRE AI - Android Starter App (Version 1.0)

इस प्रोजेक्ट में:
- Futuristic dark dashboard
- Hindi speech recognition (फोन के speech recognition service पर निर्भर)
- Hindi text-to-speech reply
- बेसिक कमांड: समय, Settings, Wi-Fi Settings, Bluetooth Settings, greeting

जरूरी सीमा:
यह शुरुआती Android ऐप है, पूर्ण ChatGPT-जैसा AI नहीं। असली AI बातचीत जोड़ने के लिए सुरक्षित backend/API server चाहिए।
अपनी API key को कभी भी Android app के source code में सीधे न डालें।

APK बनाने का तरीका:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में "Open" चुनें और REWIRE_AI फ़ोल्डर खोलें।
3. Gradle Sync पूरा होने दें।
4. फोन में Developer Options और USB debugging चालू करके USB से जोड़ें, या Emulator चलाएँ।
5. Run दबाकर ऐप टेस्ट करें।
6. APK के लिए: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में बनेगा।

फोन पर केवल ZIP डाउनलोड करने से APK अपने-आप इंस्टॉल नहीं होगा। APK बनाने के लिए Android Studio वाला कंप्यूटर आवश्यक है।

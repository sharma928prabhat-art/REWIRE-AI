package com.rewireai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else onResult?.invoke("Microphone permission is required for voice commands.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            RewireScreen(
                listen = { callback ->
                    onResult = callback
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) startListening()
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                speak = { say(it) },
                runCommand = { handleCommand(it) }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
        }
    }

    private fun say(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "rewire_reply")
    }

    private fun startListening() {
        val r = recognizer ?: run {
            onResult?.invoke("Speech recognition is not available on this device.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "REWIRE AI को अपना कमांड बोलें")
        }
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onResult?.invoke("आवाज़ समझ नहीं आई। फिर से कोशिश करें।") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                onResult?.invoke(text.ifBlank { "कुछ सुनाई नहीं दिया।" })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(intent)
    }

    private fun handleCommand(raw: String): String {
        val q = raw.lowercase(Locale.ROOT)
        val reply = when {
            q.contains("सेटिंग") || q.contains("settings") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS)); "फोन की सेटिंग खोल रहा हूँ।"
            }
            q.contains("वाईफाई") || q.contains("wi-fi") || q.contains("wifi") -> {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); "वाई-फाई सेटिंग खोल रहा हूँ।"
            }
            q.contains("ब्लूटूथ") || q.contains("bluetooth") -> {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "ब्लूटूथ सेटिंग खोल रहा हूँ।"
            }
            q.contains("समय") || q.contains("time") -> "अभी का समय ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} है।"
            q.contains("नमस्ते") || q.contains("hello") || q.contains("हेलो") -> "नमस्ते! मैं REWIRE AI हूँ। बताइए, क्या मदद चाहिए?"
            q.contains("तुम कौन") || q.contains("who are you") -> "मैं REWIRE AI, आपका वॉइस असिस्टेंट हूँ।"
            else -> "मैंने आपका कमांड सुना: $raw. अभी मेरे बेसिक कमांड उपलब्ध हैं। AI चैट जोड़ने के लिए सुरक्षित सर्वर कनेक्शन सेट करना होगा।"
        }
        say(reply)
        return reply
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun RewireScreen(
    listen: ((String) -> Unit) -> Unit,
    speak: (String) -> Unit,
    runCommand: (String) -> String
) {
    var heard by remember { mutableStateOf("माइक दबाकर बोलना शुरू करें") }
    var response by remember { mutableStateOf("नमस्ते! मैं REWIRE AI हूँ।") }
    var busy by remember { mutableStateOf(false) }
    val bg = Color(0xFF070B14)
    val cyan = Color(0xFF00D9FF)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = cyan, background = bg, surface = Color(0xFF101A2B)
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF101D35), bg, Color(0xFF05070D)))
            ).padding(22.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("REWIRE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("AI VOICE ASSISTANT", color = cyan, fontSize = 11.sp, letterSpacing = 3.sp)
                    }
                    IconButton(onClick = {
                        response = "सेटिंग्स: हिंदी वॉइस कमांड और बेसिक फोन शॉर्टकट उपलब्ध हैं।"
                        speak(response)
                    }) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = cyan) }
                }
                Spacer(Modifier.height(42.dp))
                Text("SYSTEM ONLINE", color = Color(0xFF5CF2B5), fontSize = 12.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(28.dp))
                Surface(
                    modifier = Modifier.size(208.dp),
                    shape = CircleShape,
                    color = Color(0xFF0D2940),
                    border = androidx.compose.foundation.BorderStroke(2.dp, cyan),
                    shadowElevation = 18.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Surface(
                            modifier = Modifier.size(164.dp),
                            shape = CircleShape,
                            color = Color(0xFF123B56),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF56E8FF))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                IconButton(
                                    onClick = {
                                        busy = true
                                        listen { result ->
                                            heard = result
                                            if (result.isNotBlank()) response = runCommand(result)
                                            busy = false
                                        }
                                    },
                                    modifier = Modifier.size(112.dp)
                                        .background(cyan.copy(alpha = 0.12f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color.White, modifier = Modifier.size(54.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(if (busy) "LISTENING..." else "TAP TO SPEAK", color = cyan, fontSize = 13.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(30.dp))
                InfoPanel("YOU SAID", heard)
                Spacer(Modifier.height(12.dp))
                InfoPanel("REWIRE RESPONSE", response)
                Spacer(Modifier.weight(1f))
                Text("Hindi voice • On-device speech • Basic commands", color = Color.LightGray, fontSize = 10.sp)
                Text("REWIRE AI  •  VERSION 1.0", color = cyan.copy(alpha = 0.7f), fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun InfoPanel(title: String, value: String) {
    Column(
        Modifier.fillMaxWidth().background(Color(0xCC101A2B), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Text(title, color = Color(0xFF00D9FF), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Color.White, fontSize = 14.sp)
    }
}
